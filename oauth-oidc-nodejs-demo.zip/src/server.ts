import crypto from "node:crypto";
import express from "express";
import helmet from "helmet";

const app = express();
app.use(express.json());
app.use(helmet());

const sessions = new Map<string, { state: string; nonce: string; codeVerifier: string }>();

app.get("/login", (_req, res) => {
  const sessionId = crypto.randomUUID();
  const state = crypto.randomBytes(24).toString("base64url");
  const nonce = crypto.randomBytes(24).toString("base64url");
  const codeVerifier = crypto.randomBytes(32).toString("base64url");
  const challenge = crypto.createHash("sha256").update(codeVerifier).digest("base64url");

  sessions.set(sessionId, { state, nonce, codeVerifier });

  res.json({
    message: "Demo authorization request prepared",
    sessionId,
    authorizationRequest: {
      response_type: "code",
      client_id: "demo-client",
      redirect_uri: "http://localhost:3001/callback",
      scope: "openid profile",
      state,
      nonce,
      code_challenge: challenge,
      code_challenge_method: "S256"
    }
  });
});

app.get("/callback", (req, res) => {
  const sessionId = String(req.query.sessionId ?? "");
  const state = String(req.query.state ?? "");

  const session = sessions.get(sessionId);
  if (!session) return res.status(400).json({ error: "Unknown session" });
  if (state !== session.state) return res.status(400).json({ error: "Invalid state" });

  sessions.delete(sessionId);

  res.json({
    message: "Callback accepted",
    next: "Exchange the authorization code at the token endpoint using the original PKCE code_verifier.",
    securityChecks: ["state", "nonce", "PKCE S256"]
  });
});

app.get("/protected", (_req, res) => {
  res.status(401).json({ error: "Authentication required", hint: "Attach a validated access token in production." });
});

app.listen(3001, () => console.log("OAuth/OIDC demo running on http://localhost:3001"));
