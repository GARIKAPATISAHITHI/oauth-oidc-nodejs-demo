# OAuth / OIDC Node.js Demo

A small TypeScript/Node.js demonstration of OAuth 2.0 Authorization Code + PKCE and OpenID Connect concepts.

## Demonstrates
- Authorization Code + PKCE flow concepts
- state and nonce handling
- access-token / ID-token concepts
- protected API middleware
- token claim validation

This is a learning/demo project. It does not contain real credentials or production identity-provider configuration.
